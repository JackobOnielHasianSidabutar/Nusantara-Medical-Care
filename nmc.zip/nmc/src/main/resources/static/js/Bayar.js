function showPopup(action) {
    const popup = document.getElementById("popupBayar");
    popup.style.display = "flex";
}

function hidePopup() {
    const popup = document.getElementById("popupBayar");
    popup.style.display = "none";
}
