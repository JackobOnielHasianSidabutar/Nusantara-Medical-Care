package com.example.nmc.Administrator;

import lombok.Data;

@Data
public class Administrator {
    private int idAdministrator;
    private int idKlinik;
}