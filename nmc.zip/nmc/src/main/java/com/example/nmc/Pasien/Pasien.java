package com.example.nmc.Pasien;

import lombok.Data;

@Data
public class Pasien {
    private String norekammedispasien;
    private String namapasien;
    private String nohppasien;
    private String tgllahirpasien;
    private String jeniskelaminpasien;
}
