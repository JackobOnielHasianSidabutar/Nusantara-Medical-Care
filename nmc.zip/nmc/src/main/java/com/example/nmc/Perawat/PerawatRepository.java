package com.example.nmc.Perawat;

import java.util.List;
import java.util.Optional;


public interface PerawatRepository {
    // 
}
