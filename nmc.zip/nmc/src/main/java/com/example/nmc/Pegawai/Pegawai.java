package com.example.nmc.Pegawai;

import lombok.Data;

@Data
public class Pegawai {
    private int idpegawai;
    private String usernamepegawai;
    private String passwordpegawai;
    private String namapegawai;
}
